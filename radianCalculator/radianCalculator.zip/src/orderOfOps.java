import java.lang.reflect.Array;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

public class orderOfOps {
    /* enum operation {ADDITION, SUBTRACTION, MULTIPLICATION, DIVISION, SQR, RT};
     HashMap<operation, Integer> map = new HashMap<operation, Integer>();
     map.Entry<operation.ADDITION, 2>;
     map.Entry<operation.SUBTRACTION, 2>;
     public orderOfOps(String x){
     }*/
    public String OrderOfOps(ArrayList<String> x) {
        int addition_count = 0;
        int subtraction_count = 0;
        int mult_count = 0;
        int div_count = 0;
        int sqr_count = 0;
        int root_count = 0;
        int paren_count = 0;
        for (int i = 0; i < x.size(); i++) {
            if (x.get(i).equals("+")) {
                addition_count++;
            } else if (x.get(i).equals("-")) {
                subtraction_count++;
            } else if (x.get(i).equals("*")) {
                mult_count++;
            } else if (x.get(i).equals("/")) {
                div_count++;
            } else if (x.get(i).equals("^")) {
                sqr_count++;
            } else if (x.get(i).equals("(")) {
                paren_count++;
            }
        }
        while (paren_count > 0) {
            int counter = paren_count;
            int xcounter = paren_count;
            ArrayList<String> parenthesis = new ArrayList<String>();
            int w = 0;
            int n = 0;
            //for (int n = 0; n < x.size(); n++ ) {
            while (xcounter > 0) {
                if (x.get(n).equals("(")) {
                    xcounter--;
                    n++;
                } else {
                    n++;
                }
            }
            w = n-1;
            while (!x.get(n).equals((")"))) {
                parenthesis.add(x.get(n));
                if (x.get(n).equals("+")) {
                    addition_count--;
                }
                else if (x.get(n).equals("-")){
                    subtraction_count--;
                }
                else if ( x.get(n).equals("*")){
                    mult_count--;
                }
                else if (x.get(n).equals("/")){
                    div_count--;
                }
                else if (x.get(n).equals("rt")){
                    root_count--;
                }
                else if (x.get(n).equals("sqr")){
                    sqr_count--;
                }
                x.remove(n);
            }
            if (x.get(n).equals(")")) {
                x.remove(n);
            }
            x.set(w, OrderOfOps(parenthesis));
            paren_count--;
        }


        while (sqr_count > 0) {
            while (sqr_count > 0) {

            }
        }
        while (root_count > 0){
            for (int n = 0; n < x.size(); n++){
                if (x.get(n).equals("rt"));

            }
        }
        while (div_count != 0) {
                for (int n = 0; n < x.size() - 1; n++) {
                    if (x.get(n).equals("/")) {
                        int a = Integer.parseInt(x.get(n - 1));
                        int b = Integer.parseInt(x.get(n + 1));
                        operations operation = new operations();
                        int[] c = operation.divideVals(a, b);
                        x.set(n - 1, "" + c[0] + "");
                        if (c[1] != 0){
                            x.set(n, "/");
                            x.set(n+1, "" + c[1] +"");
                        }
                        else {
                            x.remove(n);
                            x.remove(n);
                        }
                        div_count--;
                    }
                }
            }
            while (mult_count != 0) {
                for (int n = 0; n < x.size() - 1; n++) {
                    if (x.get(n).equals("*")) {
                        int a = Integer.parseInt(x.get(n - 1));
                        int b = Integer.parseInt(x.get(n + 1));
                        operations operation = new operations();
                        int c = operation.multVals(a, b);
                        x.set(n - 1, "" + c + "");
                        x.remove(n);
                        x.remove(n);
                        mult_count--;
                    }
                }

            }
            while (addition_count > 0) {
                for (int n = 0; n < x.size(); n++) {
                    if (x.get(n).equals("+")) {
                        int a = Integer.parseInt(x.get(n - 1));
                        int b = Integer.parseInt(x.get(n + 1));
                        operations operation = new operations();
                        int c = operation.addVals(a, b);
                        x.set(n - 1, "" + c + "");
                        x.remove(n);
                        x.remove(n);
                        addition_count--;
                    }
                }
            }
            while (subtraction_count > 0){
                for (int n = 0; n < x.size(); n++){
                    if (x.get(n).equals("-")){
                        int a = Integer.parseInt(x.get(n-1));
                        int b = Integer.parseInt(x.get(n+1));
                        operations operation = new operations();
                        int c = operation.subVals(a, b);
                        x.set(n-1, "" + c + "");
                        x.remove(n);
                        x.remove(n);
                        subtraction_count--;
                    }
                }
            }
        System.out.println(x.get(0));
        return x.get(0);
    }
}

